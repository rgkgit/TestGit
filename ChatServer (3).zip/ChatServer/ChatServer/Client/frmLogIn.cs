﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Client
{
    public partial class frmLogIn : Form
    {
        ReceiveClient rc = null;
        string myName;
        public frmLogIn()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUserName.Text == null || txtUserName.Text == "")
            {
                MessageBox.Show("Enter the username.", "Liberty Loans :: Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                frmClient frmClient = new frmClient();
                if (txtUserName.Text.Length > 0)
                {
                    frmClient.Show();
                    this.Hide();
                    frmClient.pnlLogin.Visible = false;
                    frmClient.pnlMain.Visible = true;
                    frmClient.txtMsgs.Enabled = true;
                    frmClient.txtSend.Enabled = true;
                    frmClient.btnSend.Enabled = true;

                    myName = txtUserName.Text.Trim();
                    frmClient.myName = myName;


                    rc = new ReceiveClient();
                    rc.Start(rc, myName);

                    rc.NewNames += new GotNames(frmClient.rc_NewNames);
                    rc.ReceiveMsg += new ReceviedMessage(frmClient.rc_ReceiveMsg);
                    frmClient.lblLoginName.Text = myName;
                    frmClient.lblAftrLoginName.Text = myName;

                    frmClient.btnCreateFolder_Click(myName);


                }
                else
                {
                    frmClient.txtMsgs.Enabled = false;
                    frmClient.txtSend.Enabled = false;
                    frmClient.btnSend.Enabled = false;
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmLogIn_Load(object sender, EventArgs e)
        {
            lblDateTime.Text = DateTime.Now.ToString("MM/dd/yyyy");
        }
    }
}
