﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
using Client.ChatService;
using System.IO;

namespace Client
{
    public partial class frmClient : Form
    {
        ReceiveClient rc = null;
        public string myName;
        public string txtMessage;
        public string lstSelectUser;
        public string senderName;
        static string FolderRoot;
        public frmClient()
        {
            InitializeComponent();
            this.FormClosing += new FormClosingEventHandler(frmClient_FormClosing);
            this.txtSend.KeyPress += new KeyPressEventHandler(txtSend_KeyPress);

        }
        
        void txtSend_KeyPress(object sender, KeyPressEventArgs e)
        {
            int keyValue = (int)e.KeyChar;

            if (keyValue == 13)
                SendMessage();

        }
        
        private void frmClient_FormClosing(object sender, EventArgs e)
        {
            rc.Stop(myName);
        }

        private void frmClient_Load(object sender, EventArgs e)
        {
            txtMsgs.Enabled = false;
            txtSend.Enabled = false;
            btnSend.Enabled = false;
        }
        
        public void rc_ReceiveMsg(string sender, string msg)
        {
            if (msg.Length > 0)

                //txtMsgs.Text += Environment.NewLine + DateTime.Now.ToShortTimeString();
                //txtMsgs.Text += Environment.NewLine + sender + ">" + msg;

                    txtMsgs.SelectionColor = Color.MidnightBlue;
                    txtMsgs.SelectedText += Environment.NewLine + DateTime.Now.ToShortTimeString();
                    txtMsgs.SelectedText += Environment.NewLine + sender + ">" + msg;

            string Sms = txtMsgs.Text;
            txtMessage = Sms;

            senderName = sender;

            string RECIVE = "SEND";
            btnWriteRecive_Click(RECIVE);

        }

        public void rc_NewNames(object sender, List<string> names)
        {
            lstClients.Items.Clear();
            foreach (string name in names)
            {
                if (name != myName)
                    lstClients.Items.Add(name);
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            SendMessage();
        }

        private void SendMessage()
        {
            rc_Statrt();
            if (lstClients.Items.Count != 0)
            {
                //txtMsgs.Text += Environment.NewLine + DateTime.Now.ToShortTimeString();
                //txtMsgs.Text += Environment.NewLine + myName + ">" + txtSend.Text;

                txtMsgs.SelectionColor = Color.Green;
                txtMsgs.SelectedText += Environment.NewLine + DateTime.Now.ToShortTimeString();
                txtMsgs.SelectedText += Environment.NewLine + myName + ">" + txtSend.Text;

                string txtSendMessage = txtMsgs.Text;
                txtMessage = txtSendMessage;

                if (lstClients.SelectedItems.Count == 0)
                    rc.SendMessage(txtSend.Text, myName, lstClients.Items[0].ToString());
                else
                    if (!string.IsNullOrEmpty(lstClients.SelectedItem.ToString()))
                    rc.SendMessage(txtSend.Text, myName, lstClients.SelectedItem.ToString());

                string SEND = "SEND";
                btnWriteSend_Click(SEND);

                txtSend.Clear();
            }
        }

        public void rc_Statrt()
        {
            rc = new ReceiveClient();
            rc.Start(rc, myName);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUserName.Text.Length > 0)
            {
                pnlLogin.Visible = false;
                pnlMain.Visible = true;
                txtMsgs.Enabled = true;
                txtSend.Enabled = true;
                btnSend.Enabled = true;

                myName = txtUserName.Text.Trim();

                rc = new ReceiveClient();
                rc.Start(rc, myName);

                rc.NewNames += new GotNames(rc_NewNames);
                rc.ReceiveMsg += new ReceviedMessage(rc_ReceiveMsg);
                lblLoginName.Text = myName;
                lblAftrLoginName.Text = myName;
            }
            else
            {
                txtMsgs.Enabled = false;
                txtSend.Enabled = false;
                btnSend.Enabled = false;
            }
        }

        private void lstClients_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblProfileName.Text = lstClients.SelectedItem.ToString();
            pbProfileActive.Visible = true;
            lblActiveNow.Visible = true;
            pnlStartChat.Visible = false;

            string User = lstClients.SelectedItem.ToString();
            lstSelectUser = User;

            string txtfileName = "SEND";
            btnRead_Click(lstSelectUser, txtfileName);
        }

        public void btnCreateFolder_Click(string FolderName)
        {
            string root = @"C:\"+FolderName;
            FolderRoot = root;
            if (!Directory.Exists(root))
            {
                Directory.CreateDirectory(root);
            }
        }

        public void btnDeleteFolder_Click(string FolderName)
        {
            string root = @"C:\"+ FolderName;
            if (Directory.Exists(root))
            {
                Directory.Delete(root);
            }
        }

        private void btnWriteSend_Click(string SEND)
        {
            string fileName = lstSelectUser + SEND + ".txt";
            string fileLoc = FolderRoot +"\\"+ fileName;
            btnDeleteFile_Click(SEND);
            btnCreate_Click(SEND);
            if (File.Exists(fileLoc))
            {
                using (StreamWriter sw = new StreamWriter(fileLoc))
                {
                    sw.Write(txtMessage);
                    sw.Close();
                }
            }
        }

        private void btnWriteRecive_Click(string RECIVE)
            {
            string fileName = lstSelectUser + "RECIVE" + ".txt";
            string fileLoc = FolderRoot + "\\" + fileName;
            btnDeleteFile_Click(RECIVE);
            btnCreate_Click(RECIVE);
            if (File.Exists(fileLoc))
            {
                using (StreamWriter sw = new StreamWriter(fileLoc))
                {
                    sw.Write(txtMessage);
                    sw.Close();
                }
            }
        }

        private void btnCreate_Click(string request)
        {
            string fileName = lstSelectUser+request + ".txt";
            string fileLoc =  FolderRoot+"\\" + fileName ;
            FileStream fs = null;
            if (!File.Exists(fileLoc))
            {
                using (fs = File.Create(fileLoc))
                {

                }
                fs.Close();
            }
        }

        private void btnDeleteFile_Click(string request)
        {
            string fileName = lstSelectUser+request + ".txt";
            string fileLoc = FolderRoot + "\\" + fileName;
            if (File.Exists(fileLoc))
            {
                File.Delete(fileLoc);
            }
        }

        private void btnRead_Click(string lstSelectUser, string txtfileName)
        {
            string fileName = txtfileName + ".txt";
            string fileLoc =  FolderRoot + "\\"+ lstSelectUser+ fileName;
            if (File.Exists(fileLoc))
            {
                using (TextReader tr = new StreamReader(fileLoc))
                {
                    txtMsgs.Text = tr.ReadToEnd();
                }
            }
            else
            {
                txtMsgs.Text = "No record found...!";
            }
        }
        
        private void txtSearch_MouseClick(object sender, MouseEventArgs e)
        {
            txtSearch.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lstClients.Enabled = true;
            pnlAftrLogin.Hide();
        }

        private void pnlListUser_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
                {
                    string myString = txtSearch.Text;
                    int index = lstClients.FindString(myString, -1);
                    if (index != -1)
                    {
                        lstClients.SetSelected(index, true);
                    }
                    else
                        MessageBox.Show("Item not found!");
                }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mniEnter_Click(object sender, EventArgs e)
        {

        }

        private void mniPrivate_Click(object sender, EventArgs e)
        {

        }

        private void mniSave_Click(object sender, EventArgs e)
        {

        }

        private void mniExit_Click(object sender, EventArgs e)
        {

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripDropDownButton1_Click(object sender, EventArgs e)
        {

        }

        private void lblLoginName_Click(object sender, EventArgs e)
        {
            frmProfile frmProfile = new frmProfile();
            frmProfile.ShowDialog();
        }

        private void logoffToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string LogInNmae = lblLoginName.Text;
            btnDeleteFolder_Click(LogInNmae);
            this.Close();
        }
    }

}
