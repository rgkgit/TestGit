﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using DataAccessLayer;
using Microsoft.AspNet.SignalR;
using POS.Models;

namespace POS.Hubs
{
    public class ChatHub : Hub
    {
        static List<UserDetail> ConnectedUsers = new List<UserDetail>();
        static List<MessageDetail> CurrentMessage = new List<MessageDetail>();
        static List<GroupDetail> GroupDetails = new List<GroupDetail>();
        DateTime localDateTime;
     
        public void Connect(int userId)
        {
            using ( POSDbContext db = new POSDbContext())
            {
                var id = Context.ConnectionId;

                var usersList = db.Users.Select(s => s).ToList();
                foreach (var items  in usersList)
                {
                    if (ConnectedUsers.Count(x => x.ConnectionId == items.UserId) == 0 && (items.UserId == userId)) 
                    {
                        var univDateTime = items.LoginTime;
                        localDateTime = univDateTime.Value.ToLocalTime();
                        string Timeonly = localDateTime.ToLongTimeString();
                        ConnectedUsers.Add(new UserDetail { ConnectionId = items.UserId, UserName = items.UserName, LoginTime = Timeonly, ContextId = id });
                    }
                    else if (ConnectedUsers.Count(x => x.ConnectionId == items.UserId) != 0 && (items.UserId == userId))
                    {
                        var item = ConnectedUsers.FirstOrDefault(x => x.ConnectionId == userId);
                        item.ContextId = id;
                    }
                    else if (ConnectedUsers.Count(x => x.ConnectionId == items.UserId) == 0)
                    {
                        string logoutTime = items.LogoutTime.ToString();
                        ConnectedUsers.Add(new UserDetail { ConnectionId = items.UserId, UserName = items.UserName, LoginTime = logoutTime });//2mints ago
                    }
                }
                var user = ConnectedUsers.FirstOrDefault(x => x.ConnectionId == userId);
                var userid = new SqlParameter("@UserId", userId);
                var groupList = db.Database.SqlQuery<GroupDetail>("dbo.GetGroup @UserId", userid).ToList();
                foreach (var group in groupList)
                    GroupDetails.Add(new GroupDetail { GroupId = group.GroupId, GroupName = group.GroupName });
                Clients.Caller.onConnected(user.ConnectionId, user.UserName, ConnectedUsers, groupList);
            }
        }
        public override System.Threading.Tasks.Task OnDisconnected(bool stopCalled)
        {
            var item = ConnectedUsers.FirstOrDefault(x => x.ContextId == Context.ConnectionId);
            var connectionId = Context.ConnectionId;
            if (item != null)
            {
                using (POSDbContext db = new POSDbContext())
                {
                    var b = db.Users.SingleOrDefault(f => f.UserId == item.ConnectionId);
                    b.LogoutTime = DateTime.UtcNow;
                    b.IsLogin = false;
                    db.SaveChanges();
                    var group = db.Groups.ToList();
                    Clients.All.onUserDisconnected(connectionId, item.UserName);
                    Clients.All.userList(ConnectedUsers, group);
                }
            }
            return base.OnDisconnected(stopCalled);
        }
        public void SendPrivateMessage(int fromUserId, int toUserId, string message,Boolean isGroup)
        {
            using (POSDbContext db = new POSDbContext())
            {
                if (!isGroup)
                {
                    var toUser = ConnectedUsers.FirstOrDefault(x => x.ConnectionId == toUserId);
                    var fromUser = ConnectedUsers.FirstOrDefault(x => x.ConnectionId == fromUserId);
                    if (toUser != null && fromUser != null)
                    {
                        string CurrentDateTime = DateTime.Now.ToString();
                        CurrentMessage.Add(new MessageDetail { fromUserId = fromUserId, toUserId = toUserId, Message = message, Time = CurrentDateTime, UserName = fromUser.UserName });
                        Chat chat = new Chat();
                        chat.FromUserId = fromUserId;
                        chat.ToUserId = toUserId;
                        chat.Message = message;
                        chat.Attachement = "";
                        chat.IsActive = true;
                        chat.ChatOn = DateTime.UtcNow;
                        chat.IsViewed = false;
                        db.Chats.Add(chat);
                        db.SaveChanges();
                        List<Chat> messages = db.Chats.Where(x => (x.ToUserId == toUserId || x.FromUserId == toUserId) && (x.ToUserId == fromUserId || x.FromUserId == fromUserId)).ToList();
                        getMessages(toUserId, fromUserId, false);
                        Clients.Client(fromUser.ContextId).sendPrivateMessage(toUser.ConnectionId, fromUser.ConnectionId, message);
                    }
                }
                else
                {
                    var toUser = GroupDetails.FirstOrDefault(x => x.GroupId == toUserId);
                    var fromUser = ConnectedUsers.FirstOrDefault(x => x.ConnectionId == fromUserId);
                    if (toUser != null && fromUser != null)
                    {
                        string CurrentDateTime = DateTime.Now.ToString();
                        CurrentMessage.Add(new MessageDetail { fromUserId = fromUserId, toUserId = toUserId, Message = message, Time = CurrentDateTime, UserName = fromUser.UserName });
                        GroupChat chat = new GroupChat();
                        chat.UserId = fromUserId;
                        chat.GroupId = toUserId;
                        chat.Message = message;
                        chat.IsActive = true;
                        chat.ChatOn = DateTime.UtcNow;
                        chat.IsViewed = false;
                        db.GroupChats.Add(chat);
                        db.SaveChanges();
                        List<GroupChat> messages = db.GroupChats.Where(x => (x.GroupId == toUserId || x.UserId == fromUserId)).ToList();
                        getMessages(toUserId, fromUserId, true);
                        Clients.Client(fromUser.ContextId).sendPrivateMessage(toUserId, fromUserId, message);
                    }
                }
            }
        }
        public void getMessages(int toUserId, int fromUserId,bool isGroup)
        {
            using (POSDbContext db = new POSDbContext())
            {
                var toUser = ConnectedUsers.FirstOrDefault(x => x.ConnectionId == toUserId);
                var fromUser = ConnectedUsers.FirstOrDefault(x => x.ConnectionId == fromUserId);
                if (isGroup)
                {
                    List<GroupChat> messages = new List<GroupChat>();
                    messages = db.GroupChats.Where(x => (x.GroupId == toUserId)).OrderByDescending(x => x.ChatOn).ToList();
                    Clients.Client(fromUser.ContextId).getMessages(messages,true);
                }
                else
                {
                    List<Chat> messages = new List<Chat>();
                    messages = db.Chats.Where(x => (x.ToUserId == toUserId || x.FromUserId == toUserId) && (x.ToUserId == fromUserId || x.FromUserId == fromUserId)).OrderByDescending(x => x.ToUserId).ToList();
                    Clients.Client(fromUser.ContextId).getMessages(messages);
                    if (toUser != null && toUser.ContextId != null)
                        Clients.Client(toUser.ContextId).getMessages(messages, false);
                }
            }
        }
        #region Group Chat
        public async Task JoinRoom(string roomName, int userId)
        {
            await Groups.Add(Context.ConnectionId, roomName);
            using (POSDbContext db = new POSDbContext())
            {
                Group group = new Group();
                if (roomName != null)
                {
                    group.GroupName = roomName;
                    group.CreatedBy = Context.ConnectionId;
                    group.UpdatedBy = Context.ConnectionId;
                    group.IsActive = true;
                    group.CreatedOn = DateTime.UtcNow;
                    group.UpdatedOn = DateTime.UtcNow;
                    db.Groups.Add(group);
                    db.SaveChanges();
                    Clients.Group(roomName).addChatMessage("You joined.", group.GroupId, roomName);
                    if (group.GroupId != 0)
                    {
                        var user = ConnectedUsers.FirstOrDefault(x => x.ConnectionId == userId);
                        GroupMap groupMap = new GroupMap();
                        groupMap.UserId = user.ConnectionId;
                        groupMap.GroupId = group.GroupId;
                        db.GroupMaps.Add(groupMap);
                        db.SaveChanges();
                    }
                    Connect(userId);
                }
            }
        }

        public Task LeaveRoom(string roomName)
        {
            return Groups.Remove(Context.ConnectionId, roomName);
        }
        #endregion
        #region Add Group Memeber

        public void GetUserList(int userId)
        {
            var users = ConnectedUsers.Where(x => x.ConnectionId != userId);
            Clients.Caller.userList(users);

        }

        public void AddMemberInGroup(int userId,int groupId)
        {
            var user = ConnectedUsers.FirstOrDefault(x => x.ConnectionId == userId);
            using (POSDbContext db = new POSDbContext())
            {
                if (user.UserID != 0)
                {
                    GroupMap groupMap = new GroupMap();
                    groupMap.UserId = user.ConnectionId;
                    groupMap.GroupId = groupId;
                    db.GroupMaps.Add(groupMap);
                    db.SaveChanges();
                }
            }
        }

        #endregion
    }
}


