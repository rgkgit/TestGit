﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataAccessLayer;

namespace POS.Controllers
{
    public class ChatController : Controller
    {

        POSDbContext db = null;
        public ChatController()
        {
            db = new POSDbContext();
        }

        [AllowAnonymous]
        public ActionResult Login()
        {
            return View();
        }

        public ActionResult GetUser(User users)
        {
            var userDetails = db.Users.Where(n => n.Email == users.Email && n.Password == users.Password).FirstOrDefault();
            if (userDetails != null)
            {
                Session["UserID"] = userDetails.UserId.ToString();
                Session["UserName"] = userDetails.UserName.ToString();
                Session["Email"] = users.Email.ToString();

                var b  = db.Users.SingleOrDefault(f => f.UserId == userDetails.UserId);
                b.LoginTime = DateTime.UtcNow;
                b.IsLogin = true;
               // b.ContextId = Guid.NewGuid().ToString();
                db.SaveChanges();
                return RedirectToAction("Chat");
            }
            else
            {
                return Content("UserName and Password is InCorrect");
            } 
        }

        [AllowAnonymous]
        public ActionResult Chat()
        {
            if (Session["UserID"] != null)
            {
                var id = Session["UserName"].ToString();
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }
        }

        public ActionResult Logout()
        {
            Session.Abandon();
            return RedirectToAction("Login","Chat");
        }
    }
}
