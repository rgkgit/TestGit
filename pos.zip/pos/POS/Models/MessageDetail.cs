﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POS.Models
{
    public class MessageDetail
    {
        public string UserName { get; set; }
        public string Message { get; set; }
        public string Time { get; set; }
        public int fromUserId { get; set; }
        public int toUserId { get; set; }
    }
}