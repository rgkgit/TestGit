﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POS.Models
{
    public class GroupDetail
    {
        public int GroupId { get; set; }
        public string GroupName { get; set; }
    }
}