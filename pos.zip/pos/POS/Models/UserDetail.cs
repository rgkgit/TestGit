﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POS.Models
{
    public class UserDetail
    {
        public int ConnectionId { get; set; }
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string LoginTime { get; set; }
        public DateTime? LogoutTime { get; set; }
        public string ContextId { get; set; }
    }
}
